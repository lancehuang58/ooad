package card;

public enum Suit {
    C, D, H,S
}
