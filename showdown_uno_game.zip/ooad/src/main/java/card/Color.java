package card;

public enum Color {
    BLUE, RED, YELLOW, GREEN;
}
