package card;

public interface Card {

}
