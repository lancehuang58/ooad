package player;

import card.Card;

public class RealPlayer<T extends Card> extends Player<T> {

    public void naming() {

    }

}
