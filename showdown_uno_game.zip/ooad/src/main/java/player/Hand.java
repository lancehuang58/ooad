package player;

import card.Card;

import java.util.ArrayList;

public class Hand<T extends Card> extends ArrayList<T> {

}
